import os
import smtplib
from email.mime.text import MIMEText
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from books_data import BOOKS_DATABASE


app = Flask(__name__)
CORS(app)


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/add-book')
def add_book():
    return render_template('add_book.html')



@app.route("/recommend", methods=["POST"])
def recommend():
    """Handle requests from frontend and return book recommendations"""
    data = request.json
    genre = data.get("genre")

    if not genre:
        return jsonify({"error": "Genre is required"}), 400

    recommendations = BOOKS_DATABASE.get(genre, [])

    return jsonify(recommendations)



if __name__ == "__main__":
    app.run(debug=True)
    
...